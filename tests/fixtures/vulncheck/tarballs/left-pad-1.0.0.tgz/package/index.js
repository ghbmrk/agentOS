// Synthetic control package for tools/vulncheck.py; not real code.
module.exports = (s) => s;
