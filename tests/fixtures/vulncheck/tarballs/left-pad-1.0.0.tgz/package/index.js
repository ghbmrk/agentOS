// Synthetic control package for tools/vulncheck.py; not real code.
module.exports = (s) => s;
exports.m0 = "agentos left-pad fingerprint literal number 1";
exports.m1 = "agentos left-pad fingerprint literal number 2";
exports.m2 = "agentos left-pad fingerprint literal number 3";
exports.m3 = "agentos left-pad fingerprint literal number 4";
exports.m4 = "agentos left-pad fingerprint literal number 5";
exports.m5 = "agentos left-pad fingerprint literal number 6";
