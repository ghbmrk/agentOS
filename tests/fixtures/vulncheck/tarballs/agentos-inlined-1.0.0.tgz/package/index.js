// Synthetic control package for tools/vulncheck.py; not real code.
exports.m0 = "agentos agentos-inlined fingerprint literal number 1";
exports.m1 = "agentos agentos-inlined fingerprint literal number 2";
exports.m2 = "agentos agentos-inlined fingerprint literal number 3";
exports.m3 = "agentos agentos-inlined fingerprint literal number 4";
exports.m4 = "agentos agentos-inlined fingerprint literal number 5";
exports.m5 = "agentos agentos-inlined fingerprint literal number 6";
