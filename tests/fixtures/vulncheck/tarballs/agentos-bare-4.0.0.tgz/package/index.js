// Synthetic control package for tools/vulncheck.py; not real code.
